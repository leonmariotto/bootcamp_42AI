#!/usr/bin/env python

from distutils.core import setup

setup(name='ai42',
      version='1.0.0',
      description='Hello',
      author='Leon Mariotto',
      packages=['ai42', 'ai42.logging']
     )
